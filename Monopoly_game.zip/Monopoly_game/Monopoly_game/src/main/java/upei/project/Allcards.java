package upei.project;
//Definition of the Allcards interface within the upei.project package
public interface Allcards {

    // Method to reset the state or properties of the implementing class
    void reset();

    // Method to set or retrieve the owner of the card based on the provided string
    String owner(String owner);

    // Method to check whether the card is owned
    // Returns 'true' if the card is owned, 'false' otherwise
    boolean isowned();

    // Method to retrieve the name of the card
    String getName();

    // Method to retrieve the price of the card
    int getPrice();

    // Method to retrieve an object representing the owner of the card
    Players getOwner_obj();

    // Method to retrieve the name of the owner of the card
    String getOwner();

    // Method to set the owner object of the card
    // Takes a parameter 'player' of type 'Players' and returns 'void'
    void set_owner_obj(Players player);


}

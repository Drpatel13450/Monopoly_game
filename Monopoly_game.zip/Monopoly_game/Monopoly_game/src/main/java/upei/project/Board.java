    package upei.project;

// Importing static members from other classes in the 'upei.project'
    import static upei.project.Exc_Cards.*;
    import static upei.project.Exc_Utilities.*;
    import static upei.project.Exc_Railroads.*;

    // Board class extending Material class
    public class Board extends Material{

        // Method to handle actions based on the player's position on the board
        public static void board(Players player, int pos){

            // Creating instances of Communitychest and Chance classes
            Communitychest ct = new Communitychest();
            Chance ce=new Chance();
            int randnum=(int) (Math.random()*12)+1;   // Generating a random number between 1 and 12
            // Switch statement to perform actions based on the player's position
            switch (pos) {
                case 0:
                    player.get_money(200);
                    break;
                case 1:
                    sendchoice(player,cards[0]);
                    break;
                case 2:
                    ct.Action(randnum,player);
                    break;
                case 3:
                    sendchoice(player,cards[1]);
                    break;
                case 4:
                    player.give_money(200);
                    break;
                case 5:
                    sendchoice(player,railroad[0]);
                    break;
                case 6:
                    sendchoice(player,cards[2]);
                    break;
                case 7:
                    ce.Action(randnum,player);
                    break;
                case 8:
                     // Virginia Avenue
                    sendchoice(player,cards[3]);
                    break;
                case 9:
                    sendchoice(player,cards[4]);
                    break;
                case 10:
                    // Jail
                    break;
                case 11:
                    sendchoice(player,cards[5]);
                    break;
                case 12:
                    sendchoice(player,utility[0]);
                    break;
                case 13:
                    sendchoice(player,cards[6]);
                    break;
                case 14:
                    sendchoice(player,cards[7]);
                    break;
                case 15:
                    sendchoice(player,railroad[1]);
                    break;
                case 16:
                    sendchoice(player,cards[8]);
                    break;
                case 17:
                    ct.Action(randnum,player);
                    break;
                case 18:
                    sendchoice(player,cards[9]);
                    break;
                case 19:
                    sendchoice(player,cards[10]);
                    break;
                case 20:
                    // free parking
                    break;
                case 21:
                    sendchoice(player,cards[11]);
                    break;
                case 22:
                    ce.Action(randnum,player);
                    break;
                case 23:
                    sendchoice(player,cards[12]);
                    break;
                case 24:
                    sendchoice(player,cards[13]);
                    break;
                case 25:
                    sendchoice(player,railroad[2]);
                    break;
                case 26:
                    sendchoice(player,cards[14]);
                    break;
                case 27:
                    sendchoice(player,cards[15]);
                    break;
                case 28:
                    sendchoice(player,utility[1]);
                    break;
                case 29:
                    sendchoice(player,cards[16]);
                    break;
                case 30:
                    //player in jail
                    break;
                case 31:
                    sendchoice(player,cards[17]);
                    break;
                case 32:
                    sendchoice(player,cards[18]);
                    break;
                case 33:
                    ct.Action(randnum,player);
                    break;
                case 34:
                    sendchoice(player,cards[19]);
                    break;
                case 35:
                    sendchoice(player,railroad[3]);
                    break;
                case 36:
                    ce.Action(randnum,player);
                    break;
                case 37:
                    sendchoice(player,cards[20]);
                    break;
                case 38:
                    player.give_money(100);
                    break;
                case 39:
                    sendchoice(player,cards[21]);
                    break;

            }

        }

        // Method to dispatch actions based on the player's choice for Card type
        public static void sendchoice(Players player, Card card){
            // Dispatching actions based on the player's name
            if(player.getName().equals("DEV")){
                execute_p1(player,card);
            }
            else if(player.getName().equals("JASHAN")){
                execute_p2(player,card);
            }
            else{
                execute_p3(player,card);
            }
        }

        // Method to dispatch actions based on the player's choice for Utilities type
        public static void sendchoice(Players player, Utilities utilities){
            // Dispatching actions based on the player's name
            if(player.getName().equals("DEV")){
                execute_p1(player,utilities);
            }
            else if(player.getName().equals("JASHAN")){
                execute_p2(player,utilities);
            }
            else{
                execute_p3(player,utilities);
            }
        }

        // Method to dispatch actions based on the player's choice for Railroads type
        public static void sendchoice(Players player, Railroads railroads){
            // Dispatching actions based on the player's name
            if(player.getName().equals("DEV")){
                execute_p1(player,railroads);
            }
            else if(player.getName().equals("JASHAN")){
                execute_p2(player,railroads);
            }
            else{
                execute_p3(player,railroads);
            }
        }


    }

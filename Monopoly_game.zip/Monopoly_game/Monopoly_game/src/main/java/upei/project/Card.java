package upei.project;

// Class representing a Card in the game
public class Card implements Allcards{

    // Private fields to store information about the card
    private String type;
    private String name;
    private int price;
    private int rent;
    private int rent1;
    private int rent2;
    private int rent3;
    private int rent4;
    private int rent5;

    private int house_value;
    private int house=0;

    private String owner="";
    Players owner_obj=new Players(""); // Assuming there's a Players class

    // Constructor to initialize the Card object with provided values
    public Card(String type, String name, int price, int rent,int rent1, int rent2, int rent3, int rent4, int rent5,int house_value) {
        this.type = type;
        this.name = name;
        this.price = price;
        this.rent =rent;
        this.rent1 = rent1;
        this.rent2 = rent2;
        this.rent3 = rent3;
        this.rent4 = rent4;
        this.rent5 = rent5;
        this.house_value=house_value;

    }

    // Getter for the name of the card
    public String getName(){
        return name;
    }

    // Getter for the price of the card
    public int getPrice(){
        return price;
    }


    // Getter for type
    public String getType() {
        return type;
    }

    // Getter for rent1
    public int getRent1() {
        return rent1;
    }

    // Getter for rent2
    public int getRent2() {
        return rent2;
    }

    // Getter for rent3
    public int getRent3() {
        return rent3;
    }

    // Getter for rent4
    public int getRent4() {
        return rent4;
    }

    // Getter for house
    public int getHouse() {
        return house+=1;
    }

    // Getter for the value of a house
    public int getHouse_value(){
        return house_value;
    }

    // Method to reduce the number of houses by 1
    public int givehouse(){
        return house-=1;
    }

    // Method to reset the card's state
    public void reset(){
        house=0;
        owner("");
        owner_obj=new Players("");
    }

    // Method to set or retrieve the owner of the card based on the provided string
    public String owner(String owner){
        this.owner=owner;
        return this.owner;
    }

    // Method to retrieve the name of the owner of the card
    public String getOwner(){
        return owner;
    }

    // Method to calculate and return the rent based on the number of houses
    public int pay_rent(){
        if (house==1){
            return rent1;
        }
        else if(house==2){
            return rent2;
        }
        else if (house==3){
            return rent3;
        }
        else if (house==4){
            return rent4;
        }
        else if(house==5){
            return rent5;
        }
        return rent;
    }

    // Method to check if the card is owned
    public boolean isowned(){
        if(this.owner!=""){
            return true;
        }
        return false;
    }

    // Method to set the owner object of the card
    public void set_owner_obj(Players player){
        owner_obj=player;
        owner=player.getName();
    }

    // Method to retrieve an object representing the owner of the card
    public Players getOwner_obj(){
        return owner_obj;
    }

}

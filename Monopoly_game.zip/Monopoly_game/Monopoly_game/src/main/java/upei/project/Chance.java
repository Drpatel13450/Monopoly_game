package upei.project;

// Class representing the Chance cards in the game
public class Chance implements Specialcards{

    // Method to perform actions based on the randomly generated number and the player's position
    public void Action(int randnum,Players player){

    switch (randnum) {

        case 1:
            // Advance to Go
            player.setPos(0);
            player.get_money(200);
            break;

        case 2:
            // Advance to Illinois Avenue
            Board b = new Board();
            player.setPos(24);
            b.board(player, player.getPos());
            break;

        case 3:
            // Bank pays you dividend of $50
            player.get_money(50);
            break;

        case 4:
            // Get out of jail free
            break;

        case 5:
            // Go to jail
            break;

        case 6:
            // Make general repairs on all your property
            player.give_money(player.total_properties()*25);
            break;

        case 7:
            // Advance to the railroad
            Board c = new Board();
            player.setPos(10);
            c.board(player, player.getPos());
            break;

        case 8:
            // Advance to St. Charles Place
            Board d = new Board();
            player.setPos(13);
            d.board(player, player.getPos());
            break;

        case 9:
            // Pay poor tax of $15
            player.give_money(15);
            break;

        case 10:
            // Take a trip to Reading Railroad
            Board e = new Board();
            player.setPos(5);
            e.board(player, player.getPos());
            break;

        case 11:
            // Advance to Boardwalk
            Board f = new Board();
            player.setPos(39);
            f.board(player, player.getPos());
            break;

        case 12:
            // Your building loan matures - collect $150
            player.get_money(150);
            break;

        default:
            break;
    }

}
}

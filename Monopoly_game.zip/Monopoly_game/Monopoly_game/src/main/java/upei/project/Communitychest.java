package upei.project;

// Class representing the Community Chest cards in the game
public class Communitychest implements Specialcards {

    // Method to perform actions based on the randomly generated number and the player's position
    public void Action(int randnum, Players player){
        switch (randnum){
                case 1:
                    // Advance to Go
                    player.setPos(0);
                    player.get_money(200);
                    break;

                case 2:
                    // Bank error in your favor
                    player.get_money(200);
                    break;

                case 3:
                    // Doctor's fees
                    player.give_money(50);
                    break;

                case 4:
                    // From sale of stock
                    player.get_money(50);
                    break;

                case 5:
                    // Get out of jail free
                    break;

                case 6:
                    // Go to jail
                    break;

                case 7:
                    // Grand Opera Night
                    player.get_money(player.total_properties()*25);
                    break;

                case 8:
                    // Income tax refund
                    player.get_money(20);
                    break;

                case 9:
                    // It's your birthday
                    player.get_money(30);
                    break;

                case 10:
                    // Life insurance matures
                    player.get_money(100);
                    break;

                case 11:
                    // Pay hospital fees
                    player.give_money(100);
                    break;

                case 12:
                    // You inherit
                    player.get_money(100);
                    break;

                default:
                    break;


        }
    }

}
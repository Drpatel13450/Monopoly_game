package upei.project;

// Class representing a pair of six-sided dice for rolling
public class Dice {

    // Private fields to store the values of each die roll
    private int roll1;
    private int roll2;

    // Method to simulate rolling two six-sided dice and return the sum
    public int roll(){
        // Generating random values for each die
        roll1 = (int) (Math.random() * 6 + 1);
        roll2 = (int) (Math.random() * 6 + 1);
        // Returning the sum of the two rolls
        return roll1 + roll2;
    }

}
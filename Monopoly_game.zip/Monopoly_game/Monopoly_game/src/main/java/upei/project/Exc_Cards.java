package upei.project;

// Class containing static methods for executing card-related actions
public class Exc_Cards {

    // Method to execute actions for player 1 (assuming properties can have houses)
    public static void execute_p1(Players player, Card card) {

        if(card.getOwner()!="" && card.getOwner()!=player.getName()){
            player.give_money(card.pay_rent());          // Pay rent to the property owner
            card.getOwner_obj().get_money(card.pay_rent());
        }
        else if(card.getOwner_obj()==player){
            // Player owns the property, build houses if they have enough cash
            if(player.getCash()>600){
                card.getHouse();
                card.getHouse();
                player.give_money(card.getHouse_value()*2);
            }
        }
        else{
            // Player can purchase the property if they have enough cash
            player.give_money(card.getPrice());
            player.get_cards(card);
            card.set_owner_obj(player);
        }

    }

    // Method to execute actions for player 2
    public static void execute_p2(Players player, Card card) {
        if(card.getOwner()!="" && card.getOwner()!=player.getName()){
            player.give_money(card.pay_rent());        // Pay rent to the property owner
            card.getOwner_obj().get_money(card.pay_rent());
        }
        else if(card.getOwner_obj()==player){
            // Player owns the property, build a house if they have enough cash
            if(player.getCash()>400){
                card.getHouse();
                player.give_money(card.getHouse_value());
            }
        }
        else{
            // Player can purchase the property if they have enough cash
            if(card.getPrice()>=200){
                player.give_money(card.getPrice());
                player.get_cards(card);
                card.set_owner_obj(player);
            }
        }
    }

    // Method to execute actions for player 3
    public static void execute_p3(Players player, Card card) {
        if(card.getOwner()!="" && card.getOwner()!=player.getName()){
            player.give_money(card.pay_rent());        // Pay rent to the property owner
            card.getOwner_obj().get_money(card.pay_rent());
        }
        else if(card.getOwner_obj()==player){
            // Player owns the property, build houses if they have enough cash
            if(player.getCash()>500){
                card.getHouse();
                card.getHouse();
                card.getHouse();
                player.give_money(card.getHouse_value()*3);
            }
        }
        else{
            // Player can purchase the property if they have enough cash
            if(card.getPrice()<=200){
                player.give_money(card.getPrice());
                player.get_cards(card);
                card.set_owner_obj(player);
            }

        }

    }

}
package upei.project;

// Class containing static methods for executing actions related to railroads
public class Exc_Railroads {

    // Method to execute actions for player 1
    public static void execute_p1(Players player, Railroads railroads) {
        if (railroads.getOwner()!="" && railroads.getOwner()!=player.getName()) {
            player.give_money(railroads.pay_rent(2));   // Pay rent to the railroad owner
            railroads.getOwner_obj().get_money(railroads.pay_rent(2));
        } else if(railroads.getOwner()!= player.getName()){
            // Player can purchase the railroad if they have enough cash
            player.give_money(railroads.getPrice());
            player.get_railroad(railroads);
            railroads.set_owner_obj(player);
        }
    }

    // Method to execute actions for player 2
    public static void execute_p2(Players player, Railroads railroads) {
        if (railroads.getOwner()!="" && railroads.getOwner()!=player.getName()) {
            player.give_money(railroads.pay_rent(2));             // Pay rent to the railroad owner
            railroads.getOwner_obj().get_money(railroads.pay_rent(2));
        } else if(railroads.getOwner()!= player.getName()){
            // Player can purchase the railroad if they have enough cash
            if (railroads.getPrice() >= 200) {
                player.give_money(railroads.getPrice());
                player.get_railroad(railroads);
                railroads.set_owner_obj(player);
            }
        }
    }

    // Method to execute actions for player 3
    public static void execute_p3(Players player, Railroads railroads) {
        if (railroads.getOwner()!="" && railroads.getOwner()!=player.getName()) {
            player.give_money(railroads.pay_rent(2));      // Pay rent to the railroad owner
            railroads.getOwner_obj().get_money(railroads.pay_rent(2));
        } else if(railroads.getOwner()!= player.getName()) {
            // Player can purchase the railroad if they have enough cash
            if (railroads.getPrice() <= 200) {
                player.give_money(railroads.getPrice());
                player.get_railroad(railroads);
                railroads.set_owner_obj(player);
            }

        }
    }
}
package upei.project;

// Class containing static methods for executing actions related to utilities
public class Exc_Utilities {

    // Method to execute actions for player 1
    public static void execute_p1(Players player, Utilities utilities) {
        if (utilities.getOwner()!="" && utilities.getOwner()!=player.getName()) {
            player.give_money(utilities.pay_rent(12));             // Pay rent to the utility owner
            utilities.getOwner_obj().get_money(utilities.pay_rent(12));
        } else if(utilities.getOwner()!= player.getName()) {
            // Player can purchase the utility if they have enough cash
            player.give_money(utilities.getPrice());
            player.get_utilites(utilities);
            utilities.set_owner_obj(player);
        }
    }

    // Method to execute actions for player 2
    public static void execute_p2(Players player, Utilities utilities) {
        if (utilities.getOwner()!="" && utilities.getOwner()!=player.getName()) {
            player.give_money(utilities.pay_rent(12));           // Pay rent to the utility owner
            utilities.getOwner_obj().get_money(utilities.pay_rent(12));
        } else if(utilities.getOwner()!= player.getName()) {
            // Player can purchase the utility if they have enough cash
            if (utilities.getPrice() >= 200) {
                player.give_money(utilities.getPrice());
                player.get_utilites(utilities);
                utilities.set_owner_obj(player);
            }
        }
    }

    // Method to execute actions for player 3
    public static void execute_p3(Players player, Utilities utilities) {
        if (utilities.getOwner()!="" && utilities.getOwner()!=player.getName()) {
            player.give_money(utilities.pay_rent(12));    // Pay rent to the utility owner
            utilities.getOwner_obj().get_money(utilities.pay_rent(12));
        }
        else if(utilities.getOwner()!= player.getName()) {
            // Player can purchase the utility if they have enough cash
            if (utilities.getPrice() <= 200) {
                player.give_money(utilities.getPrice());
                player.get_utilites(utilities);
                utilities.set_owner_obj(player);
            }

        }
    }
}
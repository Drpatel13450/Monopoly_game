package upei.project;

import java.util.ArrayList;
import static upei.project.Board.board;

/**
 * The Main class is the entry point for the Monopoly simulation.
 */
public class Main {

    public static void main(String[] args) {
        // Arrays to store game statistics
        String[] name = new String[60];
        int[] totalprop=new int[60];
        int[] cash=new int[60];

        // Loop for simulating 60 games
        for (int i = 0; i < 60; i++) {
            // Create three players for each game
            Players p1 = new Players("DEV");
            Players p2 = new Players("JASHAN");
            Players p3 = new Players("ARYA");

            // ArrayList to keep track of players in the game
            ArrayList<Players> playerarr = new ArrayList<>();
            playerarr.add(p1);
            playerarr.add(p2);
            playerarr.add(p3);

            // Game loop until only one player is left
            while (playerarr.size() != 1) {
                Dice roll = new Dice();     // Roll the dice for each player
                // Remove players with zero or negative cash
                if (p1.getCash() <= 0) {
                    playerarr.remove(p1);
                }
                if (p2.getCash() <= 0) {
                    playerarr.remove(p2);
                }
                if (p3.getCash() <= 0) {
                    playerarr.remove(p3);
                }

                // Move each player on the board based on the dice roll
                int a = roll.roll();
                if (p1.getPos() + a > 39 && p1.getCash() > 0) {
                    p1.setPos(39 - (p1.getPos() + a));
                    board(p1, p1.getPos());
                } else if (p1.getPos() + a < 39 && p1.getCash() > 0) {
                    p1.setPos(p1.getPos() + a);
                    board(p1, p1.getPos());
                }

                int b = roll.roll();
                if (p2.getPos() + b > 39 && p1.getCash() > 0) {
                    p2.setPos(39 - (p2.getPos() + b));
                    board(p2, p2.getPos());
                } else if (p2.getPos() + b < 39 && p2.getCash() > 0) {
                    p2.setPos(p2.getPos() + b);
                    board(p2, p2.getPos());
                }
                int c = roll.roll();
                if (p3.getPos() + c > 39 && p3.getCash() > 0) {
                    p3.setPos(39 - (p3.getPos() + c));
                    board(p3, p3.getPos());
                } else if (p3.getPos() + c < 39 && p3.getCash() > 0) {
                    p3.setPos(p3.getPos() + c);
                    board(p3, p3.getPos());
                }
            }

            // Record game statistics for each player
            name[i]=playerarr.get(0).getName();
            totalprop[i]=playerarr.get(0).total_properties();
            cash[i]=playerarr.get(0).getCash();
        }

        // Display overall statistics for each player
        int dev_prop = 0;
        int dev_cash = 0;
        int dev_wins=0;
        int jash_prop = 0;
        int jash_cash = 0;
        int jash_wins=0;
        int arya_prop = 0;
        int arya_cash = 0;
        int arya_wins=0;

        // Calculate and display individual player statistics
        for (int i = 0; i < 60; i++) {
            if (name[i].equals("DEV")) {
                dev_wins+=1;
                dev_prop += totalprop[i];
                dev_cash += cash[i];

            } else if (name[i].equals("JASHAN")) {
                jash_wins+=1;
                jash_prop += totalprop[i];
                jash_cash += cash[i];

            } else if (name[i].equals("ARYA")) {
                arya_wins+=1;
                arya_prop += totalprop[i];
                arya_cash += cash[i];
            }
        }

        // Display overall statistics
        System.out.println("DEV has won " + dev_wins + " times ending with an average of " + dev_prop / dev_wins + " properties per win and an average of " + dev_cash / dev_wins + " cash");
        System.out.println("JASHAN has won " + jash_wins + " times ending with an average of " + jash_prop / jash_wins + " properties per win and an average of " + jash_cash / jash_wins + " cash");
        System.out.println("ARYA has won " + arya_wins + " times ending with an average of " + arya_prop / arya_wins + " properties per win and an average of " + arya_cash / arya_wins + " cash");
    }
}
package upei.project;

//Abstract class for Material
abstract class Material {
    // Card array with specifications of the cards
    static Card[] cards = {
            new Card("Brown", "Mediterranean Avenue", 60, 2, 10, 30, 90, 160, 250, 50),
            new Card("Brown", "Baltic Avenue", 60, 4, 20, 60, 180, 320, 450, 50),
            new Card("Light Blue", "Oriental Avenue", 100, 6, 30, 90, 270, 450, 550, 50),
            new Card("Light Blue", "Vermont Avenue", 100, 6, 30, 90, 270, 450, 550, 50),
            new Card("Light Blue", "Connecticut Avenue", 120, 8, 40, 100, 300, 500, 600, 50),
            new Card("Pink", "St. Charles Place", 140, 10, 50, 150, 450, 700, 750, 100),
            new Card("Pink", "States Avenue", 140, 10, 50, 150, 450, 700, 750, 100),
            new Card("Pink", "Virginia Avenue", 160, 12, 60, 180, 500, 900, 900, 100),
            new Card("Orange", "St. James Place", 180, 14, 70, 200, 550, 950, 950, 100),
            new Card("Orange", "Tennessee Avenue", 180, 14, 70, 200, 550, 950, 950, 100),
            new Card("Orange", "New York Avenue", 200, 16, 80, 220, 600, 1000, 1000, 100),
            new Card("Red", "Kentucky Avenue", 220, 18, 90, 250, 700, 1050, 1050, 150),
            new Card("Red", "Indiana Avenue", 220, 18, 90, 250, 700, 1050, 1050, 150),
            new Card("Red", "Illinois Avenue", 240, 20, 100, 300, 750, 1100, 1100, 150),
            new Card("Yellow", "Atlantic Avenue", 260, 22, 110, 330, 800, 1200, 1200, 200),
            new Card("Yellow", "Ventnor Avenue", 260, 22, 110, 330, 800, 1200, 1200, 200),
            new Card("Yellow", "Marvin Gardens", 280, 24, 120, 360, 850, 1300, 1300, 200),
            new Card("Green", "Pacific Avenue", 300, 26, 130, 390, 900, 1100, 1275, 200),
            new Card("Green", "North Carolina Avenue", 300, 26, 130, 390, 900, 1100, 1275, 200),
            new Card("Green", "Pennsylvania Avenue", 320, 28, 150, 450, 1000, 1200, 1400, 200),
            new Card("Blue", "Park Place", 350, 35, 175, 500, 1100, 1300, 1500, 200),
            new Card("Blue", "Boardwalk", 400, 50, 200, 600, 1400, 1700, 2000, 200)
    };

    // Utilities array
    static Utilities[] utility = {
            new Utilities("Electric Company", 150),
            new Utilities("Water Works", 150)
    };

    // Railroads array
    static Railroads[] railroad = {
            new Railroads("Reading Railroad", 200),
            new Railroads("Pennsylvania Railroad", 200),
            new Railroads("B&O Railroad", 200),
            new Railroads("Short Line", 200)
    };



}

package upei.project;

import java.util.ArrayList;

//The `Players` class represents a player
public class Players {

    // Private fields to store information about the player
    private String name;
    private int pos;
    private ArrayList<Card> allcards=new ArrayList<>();
    private ArrayList<Utilities> allutilities=new ArrayList<>();
    private ArrayList<Railroads> allrailroads=new ArrayList<>();
    private int totalproperties=0;
    private int card_counter=0;
    private int cash=1500;
    private int property_value=0;

    // Constructor to initialize a player with a name and set the initial position to 0.
    public Players(String name) {
        this.name = name;
        this.pos = 0;
    }

    // Getter for 'name'
    public String getName() {
        return name;
    }

    // Setter for 'name'
    public void setName(String name) {
        this.name = name;
    }

    // Getter for 'pos'
    public int getPos() {
        return pos;
    }

    // Setter for 'pos'
    public void setPos(int pos) {
        this.pos = pos;
    }

    //Adds a card to the player's list of owned cards and updates the property value.
    public void get_cards(Card card){
        allcards.add(card);
        property_value+=card.getPrice();
    }

    //Adds a utility to the player's list of owned utilities and updates the property value.
    public void get_utilites(Utilities utilities){
        allutilities.add(utilities);
        property_value+=utilities.getPrice();
    }

    //Adds a railroad to the player's list of owned railroads and updates the property value.
    public void get_railroad(Railroads railroads){
        allrailroads.add(railroads);
        property_value+=railroads.getPrice();
    }

    //Adds money to the player's cash.
    public void get_money(int amount){
        cash+=amount;
    }

    //Subtracts money from the player's cash. If the player doesn't have enough cash, it attempts to liquidate properties to cover the deficit.
    public void give_money(int amount){
        if(cash<amount){
            // Attempt to liquidate properties if there is not enough cash
            for(int i = 0;i<allcards.size();i++){
                while(allcards.get(i).getHouse()>0 && cash<amount){
                    allcards.get(i).givehouse();      // If still insufficient, deduct the remaining amount from cash
                    get_money(allcards.get(i).getHouse_value());
                }
            }

            // Additional methods for giving back properties when selling
            if(cash<amount){
                for(int j = 0;j<allutilities.size();j++){
                    if(cash<amount){
                        give_Utilities(allutilities.get(j));
                    }
                }
                if (cash<amount){
                    for(int i = 0;i<allrailroads.size();i++){
                        if(cash<amount){
                            give_Railroads(allrailroads.get(i));
                        }
                    }
                    if(cash<amount){
                        for(int i = 0;i<allcards.size();i++){
                            if(cash<amount){
                                give_cards(allcards.get(i));
                            }
                        }
                    }
                    else{
                        cash-=amount;
                    }
                }
                else{
                    cash-=amount;
                }
            }
            else{
                cash-=amount;
            }

        }
        else{
            cash-=amount;
        }
    }
    public void give_cards(Card card){
        cash+=card.getPrice();
        card.reset();
        allcards.remove(card);
    }
    public void give_Utilities(Utilities utility){
        cash += utility.getPrice();
        utility.reset();
        allutilities.remove(utility);
    }

    public void give_Railroads(Railroads railroad){
        cash += railroad.getPrice();
        railroad.reset();
        allrailroads.remove(railroad);
    }

    //Calculates and returns the total number of properties owned by the player.
    public int total_properties(){
        totalproperties=allcards.size()+allutilities.size()+allrailroads.size();
        return totalproperties;
    }
    public void card_names(){

        for(int i=0;i<allutilities.size();i++){
            System.out.println(allutilities.get(i).getName());
            System.out.println(allutilities.get(i).getOwner());
        }
    }

    // Returns the current cash of the player.
    public int getCash(){
        return cash;
    }

    //Resets the player's cash to the initial amount
    public void setCash(){
        cash=1500;
    }

    //Resets the player's owned properties and total properties count
    public void reset(){
        allcards.clear();
        allrailroads.clear();
        allutilities.clear();
        totalproperties=0;
    }


}


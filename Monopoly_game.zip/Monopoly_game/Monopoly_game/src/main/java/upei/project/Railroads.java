package upei.project;

//The `Railroads` class represents a railroad property
public class Railroads implements Allcards{
    private String name;
    private int price;
    private String owner="";

    // Constructor to initialize a railroad with a name and price.
    public Railroads(String name, int price) {
        this.price=price;
        this.name = name;
    }

    //Getter for the price of the railroad
    public int getPrice(){
        return price;
    }

    //Getter for the name of the railroad
    public String getName () {
        return name;
    }

    //Calculates and returns the rent to be paid based on the number of owned railroads
    public int pay_rent(int num){
        if (num==4){
            return 200;
        }
        else if (num==3){
            return 100;
        }
        else if(num==2){
            return 50;
        }
        return 25;
    }

    //Sets the owner of the railroad
    public String owner(String owner){
        this.owner=owner;
        return this.owner;
    };

    //Checks if the railroad is owned by a player
    public boolean isowned(){
        if(this.owner!=""){
            return true;
        }
        return false;
    };


    Players owner_obj=new Players("");

    //Resets the owner and owner object of the railroad
    public void reset(){
        owner("");
        owner_obj=new Players("");
    }

    //Sets the owner object of the railroad
    public void set_owner_obj(Players player){
        owner_obj=player;
        owner=player.getName();
    }

    //Getter for the owner object of the railroad
    public Players getOwner_obj(){
        return owner_obj;
    }

    //Getter for the name of the owner of the railroad
    public String getOwner() {
        return owner;
    }
}


package upei.project;


// The Specialcards interface defines the actions for special cards in the Monopoly game.

public interface Specialcards {

    // Performs a specific action based on the random number generated and the player's state.
    public void Action(int randnum, Players player);
}

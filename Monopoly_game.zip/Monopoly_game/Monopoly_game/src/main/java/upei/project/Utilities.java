package upei.project;

//The `Utilities` class represents utility cards
public class Utilities implements Allcards{
    private String name;
    private int price;
    private String owner="";

    //Constructs a utility card with the specified name and price
    public Utilities(String name, int price) {
        this.price=price;
        this.name = name;
    }

        // Getter for name
        public String getName () {
            return name;
        }

        // Getter for price
        public int getPrice(){
            return price;
        }

        //Calculates and returns the rent based on the dice roll
        public int pay_rent(int dice){
            return dice*10;
        };

        //Sets the owner of the utility card
        public String owner(String owner){
            this.owner=owner;
            return this.owner;
        }

        //Checks if the utility card is owned by any player
        public boolean isowned(){
            if(this.owner!=""){
                return true;
            }
            return false;
        }

    //Additional methods for resetting, setting owner object, getting owner object, and getting owner
    Players owner_obj=new Players("");

    //Resets the owner and owner object of the utility card
    public void reset(){
        owner("");
        owner_obj=new Players("");
    }

    //Sets the owner object of the utility card
    public void set_owner_obj(Players player){
        owner_obj=player;
        owner=player.getName();
    }

    //Gets the owner object of the utility card
    public Players getOwner_obj(){
        return owner_obj;
    }

    //Gets the owner of the utility card
    public String getOwner(){
        return owner;
    }


}



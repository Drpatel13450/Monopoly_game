package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CardTest {

    @Test
    public void testGetPrice() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(100, card.getPrice(), "Card price should be 100");
    }

    @Test
    public void testGetRent1() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(60, card.getRent1(), "Rent1 should be 60");
    }

    @Test
    public void testGetRent2() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(70, card.getRent2(), "Rent2 should be 70");
    }

    @Test
    public void testGetRent3() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(80, card.getRent3(), "Rent3 should be 80");
    }

    @Test
    public void testGetRent4() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(90, card.getRent4(), "Rent4 should be 90");
    }

    @Test
    public void testGetHouse() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(1, card.getHouse(), "Initial house should be 1");
        assertEquals(2, card.getHouse(), "House should be increased to 2");
    }


    @Test
    public void testGiveHouse() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(1, card.getHouse(), "House should be 1");
        assertEquals(0, card.givehouse(), "House should be decreased to 0");
    }

    @Test
    public void testPayRent() {
        Card card = new Card("Type", "CardName", 100, 50, 60, 70, 80, 90, 100, 200);

        assertEquals(50, card.pay_rent(), "Rent should be 50 without houses");
        card.getHouse(); // Increase houses
        card.getHouse();
        assertEquals(70, card.pay_rent(), "Rent should be 70 for 2 houses");
    }


}
package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ChanceTest {

    @Test
    public void testActionCase1() {
        Players player = new Players("Player");
        Chance chance = new Chance();

        int initialPosition = player.getPos();
        int initialCash = player.getCash();

        // Simulate case 1: Advance to Go
        chance.Action(1, player);

        assertEquals(0, initialPosition, "Player should have moved to position 0 (Go)");
        assertEquals(initialCash + 200, player.getCash(), "Player should have received $200");
    }

    @Test
    public void testActionCase2() {
        Players player = new Players("Player");
        Chance chance = new Chance();

        int initialPosition = player.getPos();

        // Simulate case 2: Advance to Illinois Avenue
        chance.Action(2, player);

        assertEquals(24, player.getPos(), "Player should have moved to position 24 (Illinois Avenue)");
        assertNotEquals(initialPosition, player.getPos(), "Player position should have changed");
    }

    @Test
    public void testActionCase3() {
        Players player = new Players("Player");
        Chance chance = new Chance();

        int initialCash = player.getCash();

        // Simulate case 3: Bank pays you dividend of $50
        chance.Action(3, player);

        assertEquals(initialCash + 50, player.getCash(), "Player should have received $50");
    }
}
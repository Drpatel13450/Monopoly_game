package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CommunitychestTest {

    @Test
    public void testActionCase1() {
        Players player = new Players("Player");
        Communitychest communityChest = new Communitychest();

        int initialPosition = player.getPos();
        int initialCash = player.getCash();

        // Simulate case 1: Advance to Go
        communityChest.Action(1, player);

        assertEquals(0, initialPosition, "Player should have moved to position 0 (Go)");
        assertEquals(initialCash + 200, player.getCash(), "Player should have received $200");
    }

    @Test
    public void testActionCase2() {
        Players player = new Players("Player");
        Communitychest communityChest = new Communitychest();

        int initialCash = player.getCash();

        // Simulate case 2: Bank error in your favor
        communityChest.Action(2, player);

        assertEquals(initialCash + 200, player.getCash(), "Player should have received $200");
    }

    @Test
    public void testActionCase3() {
        Players player = new Players("Player");
        Communitychest communityChest = new Communitychest();

        int initialCash = player.getCash();

        // Simulate case 3: Doctor's fees
        communityChest.Action(3, player);

        assertEquals(initialCash - 50, player.getCash(), "Player should have paid $50");
    }
}
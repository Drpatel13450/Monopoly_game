package upei.project;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class DiceTest {

        @Test
        public void testRange() {
            Dice dice = new Dice();
            int result = dice.roll();
            assertTrue(result >= 2 && result <= 12, "Result should be in the range of 2 to 12");
        }
;
        @Test
        public void testRandomness() {
            Dice dice = new Dice();
            int result1 = dice.roll();
            int result2 = dice.roll();
            assertNotEquals(result1, result2, "Consecutive rolls should be different");
        }

        @Test
        public void testProbabilityDistribution() {
            Dice dice = new Dice();
            int[] frequency = new int[13]; // Index 0 is not used
            for (int i = 0; i < 100000; i++) {
                int result = dice.roll();
                frequency[result]++;
            }
            assertTrue(frequency[7] > frequency[2] && frequency[7] > frequency[12],
                    "Sum of 7 should have a higher probability");
        }

        @Test
        public void testRollingOnce() {
            Dice dice = new Dice();
            int result = dice.roll();
            assertNotNull(result, "Result should not be null");
        }

        @Test
        public void testRollingMultipleTimes() {
            Dice dice = new Dice();
            for (int i = 0; i < 1000; i++) {
                int result = dice.roll();
                assertTrue(result >= 2 && result <= 12, "Result should be in the range of 2 to 12");
            }
        }
}

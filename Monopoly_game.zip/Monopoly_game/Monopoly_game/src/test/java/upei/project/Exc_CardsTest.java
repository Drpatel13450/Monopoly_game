package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Exc_CardsTest {

    @Test
    public void testExecute_p1() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Card card = new Card("Brown", "Mediterranean Avenue", 60, 2, 10, 30, 90, 160, 250, 50);
        card.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Cards executor = new Exc_Cards();
        executor.execute_p1(player, card);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - card.pay_rent(), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + card.pay_rent(), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

    @Test
    public void testExecute_p2() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Card card = new Card("Pink", "St. Charles Place", 140, 10, 50, 150, 450, 700, 750, 100);
        card.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Cards executor = new Exc_Cards();
        executor.execute_p2(player, card);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - card.pay_rent(), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + card.pay_rent(), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

    @Test
    public void testExecute_p3() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Card card = new Card("Green", "North Carolina Avenue", 300, 26, 130, 390, 900, 1100, 1275, 200);
        card.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Cards executor = new Exc_Cards();
        executor.execute_p3(player, card);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - card.pay_rent(), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + card.pay_rent(), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }
}
package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Exc_RailroadsTest {

    @Test
    public void testExecute_p1() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Railroads railroads = new Railroads("Reading Railroad", 200);
        railroads.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Railroads executor = new Exc_Railroads();
        executor.execute_p1(player, railroads);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - railroads.pay_rent(2), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + railroads.pay_rent(2), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

    @Test
    public void testExecute_p2() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Railroads railroads = new Railroads("B&O Railroad", 250);
        railroads.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Railroads executor = new Exc_Railroads();
        executor.execute_p2(player, railroads);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - railroads.pay_rent(2), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + railroads.pay_rent(2), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

    @Test
    public void testExecute_p3() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Railroads railroads = new Railroads("Short Line", 150);
        railroads.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Railroads executor = new Exc_Railroads();
        executor.execute_p3(player, railroads);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - railroads.pay_rent(2), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + railroads.pay_rent(2), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

}

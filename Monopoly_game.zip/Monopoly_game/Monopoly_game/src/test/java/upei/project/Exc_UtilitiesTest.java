package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class Exc_UtilitiesTest {

    @Test
    public void testExecute_p1() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Utilities utilities = new Utilities("Electric Company", 150);
        utilities.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Utilities executor = new Exc_Utilities();
        executor.execute_p1(player, utilities);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - utilities.pay_rent(12), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + utilities.pay_rent(12), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

    @Test
    public void testExecute_p2() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Utilities utilities = new Utilities("Electric Company", 250);
        utilities.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Utilities executor = new Exc_Utilities();
        executor.execute_p2(player, utilities);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - utilities.pay_rent(12), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + utilities.pay_rent(12), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }

    @Test
    public void testExecute_p3() {
        Players owner = new Players("Owner");
        Players player = new Players("Player");
        Utilities utilities = new Utilities("Electric Company", 150);
        utilities.set_owner_obj(owner);

        int playerInitialCash = player.getCash();
        int ownerInitialCash = owner.getCash();

        Exc_Utilities executor = new Exc_Utilities();
        executor.execute_p3(player, utilities);

        int playerFinalCash = player.getCash();
        int ownerFinalCash = owner.getCash();

        assertEquals(playerInitialCash - utilities.pay_rent(12), playerFinalCash,
                "Player's cash should decrease by rent amount");
        assertEquals(ownerInitialCash + utilities.pay_rent(12), ownerFinalCash,
                "Owner's cash should increase by rent amount");
    }
}

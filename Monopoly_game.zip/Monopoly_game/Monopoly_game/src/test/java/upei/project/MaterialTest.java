package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class MaterialTest {

    @Test
    public void testCardArraySize() {
        assertEquals(22, Material.cards.length, "Card array should have 22 elements");
    }

    @Test
    public void testUtilityArraySize() {
        assertEquals(2, Material.utility.length, "Utilities array should have 2 elements");
    }

    @Test
    public void testRailroadArraySize() {
        assertEquals(4, Material.railroad.length, "Railroads array should have 4 elements");
    }


    @Test
    public void testCardProperties() {
        // Choose a card and validate its properties
        Card sampleCard = Material.cards[0];
        assertEquals("Brown", sampleCard.getType(), "Card color should match");
        assertEquals("Mediterranean Avenue", sampleCard.getName(), "Card name should match");
        assertEquals(60, sampleCard.getPrice(), "Card price should match");
        // Add more assertions based on the properties of your Card class
    }



    @Test
    public void testUtilityProperties() {
        // Choose a utility and validate its properties
        Utilities sampleUtility = Material.utility[0];
        assertEquals("Electric Company", sampleUtility.getName(), "Utility name should match");
        assertEquals(150, sampleUtility.getPrice(), "Utility price should match");
        // Add more assertions based on the properties of your Utilities class
    }

    @Test
    public void testRailroadProperties() {
        // Choose a railroad and validate its properties
        Railroads sampleRailroad = Material.railroad[0];
        assertEquals("Reading Railroad", sampleRailroad.getName(), "Railroad name should match");
        assertEquals(200, sampleRailroad.getPrice(), "Railroad price should match");
        // Add more assertions based on the properties of your Railroads class
    }
}

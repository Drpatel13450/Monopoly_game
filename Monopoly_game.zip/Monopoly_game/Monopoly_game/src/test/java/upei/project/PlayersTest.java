package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class PlayersTest {

    @Test
    public void testGetName() {
        Players player = new Players("Alice");
        assertEquals("Alice", player.getName(), "Player name should match");
    }

    @Test
    public void testGetAndSetPos() {
        Players player = new Players("Bob");
        player.setPos(5);
        assertEquals(5, player.getPos(), "Player position should match");
    }

    @Test
    public void testGetAndSetCash() {
        Players player = new Players("Charlie");
        player.setCash();
        assertEquals(1500, player.getCash(), "Player cash should be set to 1500");
    }


    @Test
    public void testCash() {
        Players player = new Players("Eve");
        assertEquals(1500, player.getCash(), "Player wealth should be 1500 initially");

        player.get_money(200);
        assertEquals(1700, player.getCash(), "Player wealth should increase after getting money");

        player.give_money(100);
        assertEquals(1600, player.getCash(), "Player wealth should decrease after giving money");
    }


}

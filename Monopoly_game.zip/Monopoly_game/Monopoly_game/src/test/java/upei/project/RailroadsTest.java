package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class RailroadsTest {

    @Test
    public void testGetName() {
        Railroads railroad = new Railroads("Reading Railroad", 200);
        assertEquals("Reading Railroad", railroad.getName(), "Name should match");
    }

    @Test
    public void testGetPrice() {
        Railroads railroad = new Railroads("Pennsylvania Railroad", 300);
        assertEquals(300, railroad.getPrice(), "Price should match");
    }

    @Test
    public void testPayRent() {
        Railroads railroad = new Railroads("B&O Railroad", 250);

        assertEquals(25, railroad.pay_rent(1), "Rent for 1 owned railroad should be 25");
        assertEquals(50, railroad.pay_rent(2), "Rent for 2 owned railroads should be 50");
        assertEquals(100, railroad.pay_rent(3), "Rent for 3 owned railroads should be 100");
        assertEquals(200, railroad.pay_rent(4), "Rent for 4 owned railroads should be 200");
    }

    @Test
    public void testSetAndGetOwner() {
        Railroads railroad = new Railroads("Short Line", 400);
        Players player = new Players("Jane");

        assertTrue(railroad.isowned(), "Initially, railroad should not be owned");

        railroad.set_owner_obj(player);

        assertTrue(railroad.isowned(), "Railroad should be owned after setting owner");

        assertEquals(player, railroad.getOwner_obj(), "Owner should match");
    }

    @Test
    public void testReset() {
        Railroads railroad = new Railroads("Pennsylvania Railroad", 300);
        Players player = new Players("Bob");

        railroad.set_owner_obj(player);

        assertTrue(railroad.isowned(), "Railroad should be owned before reset");

        railroad.reset();

        assertFalse(railroad.isowned(), "Railroad should not be owned after reset");
        assertNull(railroad.getOwner_obj(), "Owner object should be null after reset");
    }
}

package upei.project;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class UtilitiesTest {

    @Test
    public void testGetName() {
        Utilities utilities = new Utilities("Water Works", 150);
        assertEquals("Water Works", utilities.getName(), "Name should match");
    }

    @Test
    public void testGetPrice() {
        Utilities utilities = new Utilities("Electric Company", 200);
        assertEquals(200, utilities.getPrice(), "Price should match");
    }

    @Test
    public void testPayRent() {
        Utilities utilities = new Utilities("Water Works", 150);
        assertEquals(30, utilities.pay_rent(3), "Rent calculation should be correct");
    }

    @Test
    public void testSetAndGetOwner() {
        Utilities utilities = new Utilities("Electric Company", 200);
        Players player = new Players("John");

        assertFalse(utilities.isowned(), "Initially, utility should not be owned");

        utilities.set_owner_obj(player);

        assertTrue(utilities.isowned(), "Utility should be owned after setting owner");

        assertEquals(player, utilities.getOwner_obj(), "Owner should match");
    }

    @Test
    public void testReset() {
        Utilities utilities = new Utilities("Water Works", 150);
        Players player = new Players("Alice");

        utilities.set_owner_obj(player);

        assertTrue(utilities.isowned(), "Utility should be owned before reset");

        utilities.reset();

        assertFalse(utilities.isowned(), "Utility should not be owned after reset");
        assertNull(utilities.getOwner_obj(), "Owner object should be null after reset");
    }

}
